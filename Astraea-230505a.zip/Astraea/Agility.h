#ifndef AGILITY_h
#define AGILITY_h
#include "Astraea.h"

#define MaxStates   10
#define MAXSTACK    5
#define MINNWFMS    2

// State transion table loop nesting stack.
typedef struct
{
  bool Inited;
  int StartOfLoop;
  int Count;
} StateStack;

typedef struct
{
  char        name;
  double      mz,freq,q,t1,t3;
  int         ch;
  int         NumWaveforms;
  ChannelNum  DDSchannel;
  ChannelNum  DDSmodChannel;
  uint32_t    DDSfreq;
  uint16_t    Phase1;
  uint16_t    Phase2;
  PWMchannel  PWM;
} QuadState;

extern char stateTable[];
extern bool executing;
extern bool advanceScan;

// Prototypes
void defineState(void);
void clearStates(void);
void getNumStates(void);
void reportState(char *val);
void reportStates(void);
void applyState(char *val);
void executeStates(void);
void current2State(char *val, char *numWVF);
void abortStates(void);

#endif
