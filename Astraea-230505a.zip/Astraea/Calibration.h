#ifndef Calibration_h
#define Calibration_h

void CalibrateVP(int ch);
void CalibrateVN(int ch);

#endif
